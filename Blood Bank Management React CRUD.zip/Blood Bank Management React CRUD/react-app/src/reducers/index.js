import { combineReducers } from "redux";
import { dCandidate } from "./dCandidate";

export const reducers = combineReducers({
    dCandidate
})